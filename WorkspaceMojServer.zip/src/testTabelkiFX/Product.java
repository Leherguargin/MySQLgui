package testTabelkiFX;
public class Product {

    private String nazwa;
    private double price;
    private int quantity;

    public Product(){
        this.nazwa = "";
        this.price = 0;
        this.quantity = 0;
    }

    public Product(String nazwa, double price, int quantity){
        this.nazwa = nazwa;
        this.price = price;
        this.quantity = quantity;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

}