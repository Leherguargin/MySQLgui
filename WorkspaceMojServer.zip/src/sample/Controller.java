package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class Controller {
    public TextField adresSerwera;
    public TextField nazwaBazy;
    public TextField hasloUzytkownika;
    public TextField loginUzytkownika;
    public Button zaloguj;
    public Button wyloguj;
    public Button dodajTabelke;
    public Button usunTabelke;
    public Button dodajKrotke;
    public ObservableList<Tabelka> listaTabelek = FXCollections.observableArrayList();
    public TableView tabelka;


    //TableView<Tabelka> table;

    Connection conn = null;
    PreparedStatement ps;

    public void zaloguj(ActionEvent actionEvent) {

        //System.out.println("serwer: " + adresSerwera.getText() + " nazwaBazy: " + nazwaBazy.getText() + " hasloUzytkownika: " + hasloUzytkownika.getText());
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://sql." + adresSerwera.getText() + '/' + nazwaBazy.getText();
            conn = DriverManager.getConnection(url, loginUzytkownika.getText(), hasloUzytkownika.getText() );
            System.out.println("Połączono z bazą: sql." + adresSerwera.getText() + " użytkownik: " + loginUzytkownika.getText() );

            /*//System.out.println("\nTabelki znajdujące się w bazie to: ");
            ResultSet wszystkieTabelki = conn.prepareStatement("show tables;").executeQuery();
            List wszystkieTabelkiLista = zapisDoListy(wszystkieTabelki);//arraylista z stringami
            for(int i=0;i<wszystkieTabelkiLista.size();i++){ //dodanie wszystkich tabelek do listy observable
                listaTabelek.add(new Tabelka((String)wszystkieTabelkiLista.get(i)));
            }*/


            //listaTabelek.addAll(wszystkieTabelkiLista);

            //Name column
            /*TableColumn<String, String> pierwszaKolumna = new TableColumn<>(adresSerwera.getText());
            pierwszaKolumna.setMinWidth(200);
            pierwszaKolumna.setCellValueFactory(new PropertyValueFactory<>("nazwaTabeli"));*/


            /*tabelka.getColumns().add(pierwszaKolumna);
            tabelka.setItems(listaTabelek);*/


            //tabelka.getColumns().add(wszystkieTabelki);
            zaloguj.setDisable(true);
            wyloguj.setDisable(false);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e){
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //Name column
        TableColumn<Tabelka, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setMinWidth(200);
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("nazwa"));

        //table = new TableView<>();
        tabelka.setItems(getProduct());
        tabelka.getColumns().addAll(nameColumn/*, priceColumn, quantityColumn*/);

    }

    public void dodajTabelke(ActionEvent actionEvent) {
        //todo otworz okienko dodawania tabelki
        if(conn != null){
            try {
                ps = conn.prepareStatement("CREATE TABLE InnaTabelka (" +
                        "id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY," +
                        "imie VARCHAR(30) NOT NULL," +
                        "nazwisko VARCHAR(30) NOT NULL," +
                        "kraj VARCHAR(30)," +
                        "zarobki INTEGER" +
                        ")");
                ps.executeUpdate();
                System.out.println("Dodano tabelke.");
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
        else
            System.out.println("Nie połączono do bazy danych!"); //todo wyświetl bledy użytkownikowi

    }

    public void usunTabelke(ActionEvent actionEvent) {
    }

    public void dodajKrotke(ActionEvent actionEvent) {
    }

    public static void printResult(ResultSet rs) throws Exception
    {
        while (rs.next()) {
            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                if (i > 1) System.out.print(",  ");
                String columnValue = rs.getString(i);
                System.out.print(columnValue + " ");
            }
            System.out.println();
        }
    }

    public static List zapisDoListy(ResultSet rs) throws Exception
    {
        List<String> list = new ArrayList<String>();
        while (rs.next()) {
            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                //if (i > 1) list.add(",  ");
                String columnValue = rs.getString(i);
                list.add(columnValue);
            }
        }
        return list;
    }

    //Get all of the products
    public ObservableList<Tabelka> getProduct(){
        ObservableList<Tabelka> products = FXCollections.observableArrayList();
        products.add(new Tabelka("pierwsza"));
        products.add(new Tabelka("druga"));
        products.add(new Tabelka("trzecia"));
        return products;
    }

    public void wyloguj(ActionEvent actionEvent) {
        System.out.println("Zakonczono");
        try {
            conn.close();
            wyloguj.setDisable(true);
            zaloguj.setDisable(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
