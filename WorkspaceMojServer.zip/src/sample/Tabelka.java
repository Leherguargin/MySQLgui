package sample;

public class Tabelka {
    String nazwa;

    public Tabelka(String nazwa) {
        this.nazwa = nazwa;
    }
}
